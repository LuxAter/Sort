#ifndef _INSERTION_SORT_
#define _INSERTION_SORT_
#include "../sort_core.h"
#include <ctime>
#include <iostream>
#include <pessum.h>
#include <vector>
namespace sort {
double InsertionSort(bool display = false);
}
#endif
