#ifndef _SELECTION_SORT_
#define _SELECTION_SORT_
#include "../sort_core.h"
#include <ctime>
#include <iostream>
#include <pessum.h>
#include <vector>
namespace sort {
double SelectionSort(bool display = false);
}
#endif
